<?php include("header.php"); ?>
<div class="container">
	<div class="row">	
		<div class="jumbotron"><i><h1>About Us</h1></i>
			We enable businesses to transform the way they market, sell, operate and improve their efficiencies. We provide the technology infrastructure and marketing reach to help merchants, brands and other businesses to leverage the power of new technology to engage with their users and customers and operate in a more efficient way.

Our businesses are comprised of core commerce, cloud computing, digital media and entertainment, and innovation initiatives. In addition, Ant Financial, a company in which we have agreed to acquire a 33% equity stake, provides payment and financial services to consumers and merchants on our platforms. An ecosystem has developed around our platforms and businesses that consists of consumers, merchants, brands, retailers, other businesses, third-party service providers and strategic alliance partners.
		</div>
	</div>
</div>

<?php include("footer.php"); ?>

