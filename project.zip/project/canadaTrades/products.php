<?php include("header.php"); ?>
<div class="container">
	<div class="row">	
		<?php
			$query = "SELECT * FROM products WHERE `products`.`date` > NOW() - INTERVAL 15 DAY AND `products`.`quantity` != '0' ORDER BY `pid` DESC";
			$result = mysqli_query($conn,$query);
		
			while($row = mysqli_fetch_array( $result ))
			{ ?>
				<div class="col-md-4 product">
					<a href="product.php?id=<?php echo $row['pid']; ?>"><img src="images/<?php echo $row['image']; ?> " width='200px' height='200px'/></a>
					<p class="name"><?php echo $row['name']; ?></p>
					<p class="description"><?php echo $row['description']; ?></p>
					<p class="price">$<?php echo $row['price']; ?></p>
					<p class="quantity"><?php echo $row['quantity']; ?> Items Remaining</p>
					<?php if(!empty($_SESSION['id']) && $_SESSION['id'] != "") {?>
					<a class="add_to_cart" href="cart.php?id=<?php echo $row['pid']; ?>">ADD TO CART</a>
					<?php } ?>
				</div>
			<?php }
		?>		
	</div>
</div>

<?php include("footer.php"); ?>

