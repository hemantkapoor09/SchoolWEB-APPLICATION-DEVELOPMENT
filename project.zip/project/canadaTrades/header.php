<?php 
	include("db.php");
	session_start();
?>
<?php 
	$activePage = basename($_SERVER['PHP_SELF'], ".php");
?>
<html>
	<head>
		<title>Shop Online</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" href="css/style.css" type="text/css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>
		<nav class="navbar bg-dark">
		  <div class="container-fluid">
			<div class="navbar-header">
			  <a class="navbar-brand" href="home.php">Canada Trade</a>
			</div>
			<ul class="nav navbar-nav tabb">
			  <li class="hd <?php if($activePage =='home'){ echo 'active'; } ?>"><a href="home.php">Home</a></li>
			  <li class="hd <?php if($activePage =='products'){ echo 'active'; } ?>"><a href="products.php">Products</a></li>
			  <li class="hd <?php if($activePage =='contact'){ echo 'active'; } ?>"><a href="contact.php">Contact Us</a></li>
			  <li class="hd <?php if($activePage =='about'){ echo 'active'; } ?>"><a href="about.php">About Us</a></li>
			  <?php if(!empty($_SESSION['id']) && $_SESSION['id'] != "") {?>
			  <li class="hd <?php if($activePage =='profile'){ echo 'active'; } ?>"><a href="profile.php">Profile</a></li>
			  <li class="hd <?php if($activePage =='logout'){ echo 'active'; } ?>"><a href="logout.php">Logout</a></li>
			  <?php }else{ ?>
			  <li class="hd <?php if($activePage =='login'){ echo 'active'; } ?>"><a href="login.php">Login</a></li>
			  <?php } ?>
			</ul>
		  </div>
		</nav>
	