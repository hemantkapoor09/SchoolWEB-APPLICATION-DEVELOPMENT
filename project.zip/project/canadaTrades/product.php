<?php include("header.php"); 
$id = $_GET["id"];
$user_id = $_SESSION['id'];
?>
<div class="container">
	<div class="row">	
		<?php
			$query = "SELECT `products`.`pid`,`products`.`image`,`products`.`name`, `products`.`price`, `products`.`description`,`products`.`quantity`,`users`.`uname` FROM `products` INNER JOIN `users` ON `products`.`owner_id` = `users`.`id` WHERE `products`.`pid` = '$id'";
			$result = mysqli_query($conn,$query);
		
			while($row = mysqli_fetch_array( $result ))
			{ ?>
				<div class="col-md-6 col-offset-3" style="border:#00f solid 2px;">
					<img src="images/<?php echo $row['image']; ?> " width='200px' height='200px'/>
					<p><?php echo $row['name']; ?></p>
					<p><?php echo $row['description']; ?></p>
					<p>$<?php echo $row['price']; ?></p>
					<p><?php echo $row['quantity']; ?> Items Remaining</p>
					<p>Product Added By : <?php echo $row['uname']; ?> </p>
					<?php if(!empty($_SESSION['id']) && $_SESSION['id'] != "") {?>
					<a href="cart.php?id=<?php echo $row['pid']; ?>">ADD TO CART</a>
					<?php } ?>
				</div>
			<?php }
		?>
	</div>
</div>
<?php include("footer.php"); ?>
