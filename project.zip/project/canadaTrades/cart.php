<?php include("header.php"); 
$id = $_GET["id"];
$user_id = $_SESSION['id'];
?>
<div class="container">
	<div class="row">	
		<div class="col-md-8" style="margin-left:15%;">
			<i><h2>Palce oder / Check Out</h2></i>
			<form method="post" action="">
				<div class="form-group">
					<input type="text" name="name_card"  class="form-control" tabindex="1" placeholder="NAME ON CARD"/>
				</div>
				<div class="form-group">
					<input type="text" name="card_number"  class="form-control" placeholder="ENTER CARD NUMBER"/>
				</div>
				<div class="form-group">
					<input type="date" name="expiry_date" class="form-control" placeholder="EXPIRY DATE"/>
				</div>
				<div class="form-group">
					<input type="text" name="cvv" class="form-control" tabindex="1" placeholder="CVV"/>
				</div>
				<div class="form-group">
					<input type="submit" name="submit"  value="Submit"/>
				</div>
			</form>
		</div><br><hr>
		<?php
			$query = "SELECT * FROM products WHERE pid = '$id'";
			$result = mysqli_query($conn,$query);
		
			while($row = mysqli_fetch_array( $result ))
			{ ?>
				<div class="col-md-6" style="margin-left:30%;">
					<img src="images/<?php echo $row['image']; ?> " width='200px' height='200px'/>
					<h3><?php echo $row['name']; ?></h3>
					<i><h4><?php echo $row['description']; ?></h4></i>
					<p>$<?php echo $row['price']; ?></p>
					<i><p>Left With <?php echo $row['quantity']; ?> only !</p></i>
				</div>
			<?php }
		?>
	</div>
</div>
<?php include("footer.php"); ?>

<?php 
	if(isset($_POST["submit"])){
		$card_number = $_POST["card_number"];
		$query = "INSERT INTO `order` (`product_id`,`user_id`,`card_number`,`date`) VALUES ('$id','$user_id','$card_number',CURDATE())";
		mysqli_query($conn,$query);
		$query2 = "UPDATE `products` SET `quantity` = `quantity`-1 WHERE `pid` = '$id'";
		mysqli_query($conn,$query2);
		echo "<script>
				alert('Order Placed.');
				window.location.href='profile.php';
			</script>";
	}
?>