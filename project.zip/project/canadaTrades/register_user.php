<?php include("header.php"); ?>
<div class="container">
	<div class="row">
		<?php
			if($_POST["register-submit"]){
				$name = $_POST["name"];
				$email = $_POST["email"];
				$password = $_POST["password"];
				$confirm_password = $_POST["confirm-password"];
				
				if($password == $confirm_password){
					$query = "INSERT INTO `users` (`uname`,`email`,`password`) VALUES ('$name','$email','$confirm_password')";
					mysqli_query($conn,$query);
					echo "<script>
							alert('Registration Successful! Login to continue.');
							window.location.href='login.php';
						</script>";
				}else{
					echo "Both Passwords must be same!";
				}
			}
		?>
	</div>
</div>
<?php include("footer.php"); ?>