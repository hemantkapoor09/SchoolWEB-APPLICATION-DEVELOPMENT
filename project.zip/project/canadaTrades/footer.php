</div>
    <!-- Footer -->
    <footer class="py-3 bg-dark">
      <div class="container">
        <h4 class="m-0 text-center" style="color:#333;">Copyright &copy; <i>CanadaTrade.ca</i></h4>
      </div>
      <!-- /.container -->
    </footer>
<br><br>
    <!-- Bootstrap core JavaScript -->

		<script src="js/script.js"></script>
  </body>

</html>