<?php include("header.php"); ?>
<div class="container">
	<div class="row">
		<?php
			if($_POST["login-submit"]){
				$email = $_POST["email"];
				$password = $_POST["password"];
								
				$query = "SELECT * FROM `users` WHERE `email` = '$email' AND `password` = '$password'";
				$result = mysqli_query($conn,$query);
				$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
				  
				$count = mysqli_num_rows($result);
				if($count == 1) {
					echo "Welcome ".$row["name"];
					$_SESSION['id'] = $row["id"];
					$_SESSION['name'] = $row["uname"];
					header("location: home.php");
				}else {
					echo "Your Login Name or Password is invalid";
				}
				
			}
		?>
	</div>
</div>
<?php include("footer.php"); ?>