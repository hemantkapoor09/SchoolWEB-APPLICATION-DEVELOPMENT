-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2018 at 02:05 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `card_number` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `product_id`, `user_id`, `card_number`, `date`) VALUES
(9, 15, 7, '', '2018-10-23'),
(10, 14, 7, '', '2018-10-23'),
(11, 16, 8, '', '2018-10-23'),
(12, 21, 8, '', '2018-10-23');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL,
  `date` date NOT NULL,
  `owner_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `name`, `description`, `image`, `price`, `quantity`, `date`, `owner_id`) VALUES
(14, 'Heater', 'It heats from anywhere you can change through phone', 'heat.jpg', '65.2', 44, '2018-10-23', 7),
(15, 'MIcrosoft Surface', 'Best for all purpose and on top best design', '511dPerd+-L._SL1200_.jpg', '89.23', 47, '2018-10-23', 7),
(16, 'Asus Gamming Laptop', 'Super Gammig laptop with in-built graphics of 8gb and nvidia G-Force of 10gb', '61-aOC3sVwL._SL1500_.jpg', '2508.65', 5, '2018-10-23', 8),
(17, 'Tread Mill', 'Run and loose fat', '81YfnFowb4L._SL1500_.jpg', '102.5', 8, '2018-10-23', 8),
(18, 'Blender', 'A great food processor', '71t+HMxMIqL._SL1385_.jpg', '506.56', 16, '2018-10-23', 8),
(19, 'Therometer', 'Infrared thermometer', '81-GR4q2IPL._SL1500_.jpg', '12.56', 8, '2018-10-23', 8),
(20, 'Fitbit', 'A smart wactch for smart guyz', '81m2Y6TJXVL._SL1500_.jpg', '102.45', 56, '2018-10-23', 8),
(21, 'Amazon Alexa', 'A smart home product for chatting and interacting with ', '71uB9tuw2JL._SL1000_.jpg', '109.78', 86, '2018-10-23', 8);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `uname`, `email`, `password`) VALUES
(7, 'hemant', 'admin@ct.com', '123'),
(8, 'admin', 'admin@admin.com', '123'),
(9, 'john', 'john@shop.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
