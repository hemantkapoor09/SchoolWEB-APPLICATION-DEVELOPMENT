<?php 
	session_start();
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>My Games</title>
	 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<style>
		td{
			width:100px;
			height:200px;
		}
		image{
			width:80px;
			height:100px;
		}
		.center-block{
			margin-left:33%;
		}
	</style>
</head>
 <body>

 	<div class="container">
 		<h4>
 			<?php 
 				echo "welcome &nbsp;" . $_SESSION["username"]."";
 			 ?>
 		</h4>
 	<div class="row center-block">
 		<form class="form_text" action='addgame.php' method='post'>
			  <div class="form-group">
			    <label for="name">Name:</label>
			    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Game Name">
			  </div>
			  
			  <div class="form-group">
			    <label for="name">Image:</label>
			    <input type="file" class="form-control" id="image" name="image" placeholder="Quality  of Game">
			  </div>

			  <div class="form-group">
			    <label for="name">Quality:</label>
			    <input type="text" class="form-control" id="quality" name="quality" placeholder="Quality  of Game">
			  </div>
			  
			  <div class="form-group">
			    <label for="name">Price(CAD):</label>
			    <input type="text" class="form-control" id="price" name="price" placeholder="$">
			  </div>
			  
			  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
			</form>		
 	</div>
	</div>
</body>
</html>