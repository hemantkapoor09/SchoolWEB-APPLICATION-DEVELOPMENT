<?php 
	session_start();
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>My Games</title>
	 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<style>
		td{
			width:100px;
			height:200px;
		}
		image{
			width:80px;
			height:100px;
		}
		.center-block{
			margin-left:33%;
		}
	</style>
</head>
 <body>

 	<div class="container">
 		<h4>
 			<?php 
 				echo "welcome &nbsp;" . $_SESSION["username"]."";
 			 ?>
 		</h4>
 		<a href="newGame.php">Add Game</a><br>
 		<a href="login.php">login</a>
 		<div class="row center-block">
 			<table border="1">
 				<tr>
 					<td>bb</td>
 					<td><img src="a.jpg"></td>
 					<td>40</td>
 					<td>70</td>
 				</tr>
 				<tr>
 					<td>bb</td>
 					<td><img src="a.jpg"></td>
 					<td>40</td>
 					<td>70</td>
 				</tr>
 				<tr>
 					<td>bb</td>
 					<td><img src="a.jpg"></td>
 					<td>40</td>
 					<td>70</td>
 				</tr>
 			</table>
 		</div>
 	</div>
 </body>
 </html>