<?php 
	$file="users.txt";
	$linecount = 0;
	$handle = fopen($file, "r");
	while(!feof($handle)){
	  $line = fgets($handle);
	  $linecount++;
	}

	fclose($handle);

	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$myfile = fopen($file, "a") or die("Unable to open file!");
	$txt="".$linecount.",".$username.",".$email.",".$password.",".$fname.",".$lname."\n"."";
	file_put_contents($file, ""."\n".$txt, FILE_APPEND | LOCK_EX);
	fclose($myfile);
	header ("Location: login.php");
 ?>