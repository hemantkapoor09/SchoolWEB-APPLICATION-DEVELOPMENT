<?php 
		$name = $_POST['name'];
		
$uploaddir = 'images/';
$uploadfile = $uploaddir . basename($_FILES['image']['name']);

if (move_uploaded_file($_FILES['image']['tempname'], $uploadfile)) {
    echo "File is valid, and was successfully uploaded.\n";
		$file="games.txt";
		$image = $_POST['image'];
		$quality = $_POST['quality'];
		$price = $_POST['price'];
		$myfile = fopen($file, "a") or die("Unable to open file!");
		$txt="".$name.",".$image.",".$quality.",".$price."\n"."";
		file_put_contents($file, ""."\n".$txt, FILE_APPEND | LOCK_EX);
		fclose($myfile);
		echo($txt);
} else {
    echo "Possible file upload attack!\n";
}

	// header ("Location: index.php");
 ?>