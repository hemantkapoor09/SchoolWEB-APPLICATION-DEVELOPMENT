<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Signup Form</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<style>
	body{
		background: #555;

	}
		.box{
			width: 50%;
			margin: 0 auto;
			background: #fff;
			box-shadow: 2px 2px 20px #000;
			margin-top: 5%;
			padding: 0;
		}
		.login_text{
			color:#765;
			background:#2e6da4;
			padding:2%;
			color:#fff;
		}
		.form_text{
			padding:4%;
		}
	</style>
</head>
<body >
	<div class = "container dc">
		<div class="box">
		<h2 class="login_text">Signup</h2>
			<form class="form_text" action = "userStore.php" method = "post">
			  <div class="form-group">
			    <label for="firstname">First Name:</label>
			    <input type="text" class="form-control" id="fname" name="fname" placeholder="First Name">
			  </div>
			  <div class="form-group">
			    <label for="lastname">Last Name:</label>
			    <input type="lastname" class="form-control" id="lname" name="lname" placeholder="Last Name">
			  </div>
			  <div class="form-group">
			    <label for="username">User Name:</label>
			    <input type="username" class="form-control" id="username" name="username" placeholder="User Name">
			  </div>
			  <div class="form-group">
			    <label for="email">Email address:</label>
			    <input type="email" class="form-control" id="email"  name="email" placeholder="Enter Email">
			  </div>
			  <div class="form-group">
			    <label for="pwd">Password:</label>
			    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
			  </div><br>
			  <button type="submit" class="btn btn-primary"  name="submit">Submit</button>
			</form>	
			<div class="panel-group">
			  <div class="panel panel-default dc">
			    <div class="panel-body">
			    	<div class="col-lg-12 text-center">
			    		<h6><p>If already have an account <a href="login.php">Login</a></p></h6>
			    	</div>
			    </div>
			  </div>
			</div>
		</div>
	</div>
</div>
</body>
</html>