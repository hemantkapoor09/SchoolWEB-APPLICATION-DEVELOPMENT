<?php 
	session_start();
	$file ="users.txt";
	$userN = $_POST['username'];
	$passW = $_POST['password'];
	$userlist = file($file);
	$success = false;
	foreach ($userlist as $user) {
	    $user_details = explode(',', $user);
	    if ($user_details[1] == $userN && $user_details[3] == $passW) {
	        $username=$user_details[1];
	        $success = true;
	        break;
	    }
	}
	

	// if ($success) {
	//     echo "<br> Hi $userN you have been logged in. <br>";
	// } else {
	//     echo "<br> You have entered the wrong username or password. Please try again. <br>";
	// }

	$_SESSION["username"] = $userN;
     header ("Location: index.php");
 
 ?>