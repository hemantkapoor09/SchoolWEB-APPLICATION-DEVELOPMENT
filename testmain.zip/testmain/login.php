<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login Form</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<style>
	body{
		background: #555;

	}
		.box{
			width: 50%;
			margin: 0 auto;
			background: #fff;
			box-shadow: 2px 2px 20px #000;
			margin-top: 10%;
			padding: 0;
		}
		.login_text{
			color: #765;
			background: #2e6da4;
			padding: 2%;
			color: #fff;
		}
		.form_text{
			padding: 4%;
		}
	</style>
</head>
<body >
	<div class = "container">
		<div class="box">
		<h2 class="login_text">Login</h2>
			<form class="form_text" action='validateUser.php' method='post'>
			  <div class="form-group">
			    <label for="username">User Name:</label>
			    <input type="username" class="form-control" id="username" name="username" placeholder="Enter User Name">
			  </div>
			  <div class="form-group">
			    <label for="pwd">Password:</label>
			    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
			  </div>
			  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
			</form>	
			<div class="panel-group">
			  <div class="panel panel-default dc">
			    <div class="panel-body">
			    	<div class="col-lg-12 pull-right">
			    	<h6 class="pull-right"><p>Create an account  <a href="registration.php">Registered Now</a></p></h6>
			    	</div>
			    </div>
			  </div>
			</div>
		</div>
	</div>
</div>
</body>
</html>