<!DOCTYPE html>
<html>
<head>
	<title>Pet Shop</title>
</head>
<body>

</body>
</html>
<?php

//DB Connection
	$server = "localhost";
	$user = "root";
	$password = "";
	$mydb = "midterm";
	
	$conn = new mysqli($server, $user, $password, $mydb);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		echo "Connected successfully";
	}

	$temp = "SELECT * FROM midterm ";
	$result = $conn->query($temp);
	echo("<br><br><font>".$result[0]."</font>");

	// 1
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Tiger', '2012-10-04 00:00:00', '2022.75','2012-10-04 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

	// 2
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Loin', '2012-10-04 00:00:00', '4022.75','2012-10-04 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

	// 3
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Boor', '2012-10-04 00:00:00', '1022.75','2012-10-04 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

	// 4
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Scipper', '2012-10-04 00:00:00', '452','2018-07-24 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

	// 5
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Bolt', '2018-07-24 00:00:00', '8022.75','2018-07-24 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

	// 6
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Molt', '2018-07-24 00:00:00', '762.50','2018-07-24 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

	// 7
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Mickey', '2018-07-24 00:00:00', '452.70','2018-07-24 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

		
	// 8
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Roby', '2018-07-24 00:00:00', '952.42','2018-07-24 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}
	// 9
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Linsey', '2018-07-24 00:00:00', '9992.42','2018-07-24 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

	// 10
		$sql = "INSERT INTO midterm (petName, dateOfBirth, price, dateSoled)
			VALUES ('Bony', '2018-07-24 00:00:00', '1928.28','2018-07-24 00:00:00')";

		if ($conn->query($sql) === TRUE) {
		    echo "<br>New record created successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}


		$conn->close();
		
// function ageCalculator($dob){
//     if(!empty($dob)){
//         $birthdate = new DateTime($dob);
//         $today   = new DateTime('today');
//         $ag = $birthdate->diff($today)->y;
//         return "$ag";
//     }else{
//         return 0;
//     }
// }

// $row11 = array('dob'=>'02-01-2015');
// $age = ageCalculator($row11['dob']);
// if($age > 5)
// {
	
// }

  ?>