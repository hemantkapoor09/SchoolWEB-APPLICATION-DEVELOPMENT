<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<style>
	.for{
		margin-left:30%;
		margin-top:2%;
	}
	#but{
		margin-left:17%;
	}
</style>
<body>
	<div class="for">
	<form action="validatelogin.php" method="post">
		User Name: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<input type="text" name="usname"><br><br>
		Password: &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<input type="password" name="pass"><br><br>
		Confirm Password: &nbsp;<input type="password" name="repass"><br><br>
		<br>
		<input type="submit" id="but" value="Log In"/>
	</form>
	</div>

</body>
</html>
<?php

	if (!empty($_GET["msg"]))
	{
		echo("<br><br><font color=red>".$_GET["msg"]."</font>");
	}
?>