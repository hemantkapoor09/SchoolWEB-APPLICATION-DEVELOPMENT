<?php 
	$username = $_POST["usname"];
	$password = $_POST["pass"];
	$repassword = $_POST["repass"];
	$passwordErr = ""; 	
 	if(ctype_lower($username) && !empty($password) && $password == $repassword)
 	{
 		if (strlen($password) <= '7') 
 		{
        	$passwordErr = "Your Password Must Contain At Least 8 Characters!";
   			header("Location: login.php?msg=".$passwordErr, true, 301);
    	}
	    elseif ( !preg_match ("/^[a-zA-Z\s]+$/",$password)) 
	    {
	   		$passwordErr = "Password must only contain letters!";
   			header("Location: login.php?msg=".$passwordErr, true, 301);
		} 
	}
		else{
			$passwordErr = "You Have Created Your Account With us Sucessfully !";
   			header("Location: login.php?msg=".$passwordErr, true, 301);
		}
 ?>